export const autos = [
    {
        modelo: 'Chevrolet',
        año: '2002',
        precio: '22000000',
        imagen: 'auto1.jpg'
    },
    {
        modelo: 'Ford',
        año: '2010',
        precio: '35000000',
        imagen: 'auto2.jpg'
    },
    {
        modelo: 'Toyota',
        año: '2015',
        precio: '40000000',
        imagen: 'auto3.jpg'
    },
    {
        modelo: 'Honda',
        año: '2018',
        precio: '45000000',
        imagen: 'auto4.jpg'
    },
    {
        modelo: 'Nissan',
        año: '2020',
        precio: '50000000',
        imagen: 'auto5.jpg'
    },
    {
        modelo: 'Mazda',
        año: '2017',
        precio: '38000000',
        imagen: 'auto6.jpg'
    },
    {
        modelo: 'Hyundai',
        año: '2019',
        precio: '43000000',
        imagen: 'auto7.jpg'
    },
    {
        modelo: 'Kia',
        año: '2021',
        precio: '48000000',
        imagen: 'auto8.jpg'
    },
    {
        modelo: 'Volkswagen',
        año: '2014',
        precio: '37000000',
        imagen: 'auto9.jpg'
    },
    {
        modelo: 'Audi',
        año: '2016',
        precio: '60000000',
        imagen: 'auto10.jpg'
    },
    {
        modelo: 'BMW',
        año: '2013',
        precio: '75000000',
        imagen: 'auto11.jpg'
    },
    {
        modelo: 'Mercedes-Benz',
        año: '2012',
        precio: '80000000',
        imagen: 'auto12.jpg'
    },
    {
        modelo: 'Subaru',
        año: '2011',
        precio: '32000000',
        imagen: 'auto13.jpg'
    },
    {
        modelo: 'Volvo',
        año: '2009',
        precio: '42000000',
        imagen: 'auto14.jpg'
    },
    {
        modelo: 'Jaguar',
        año: '2022',
        precio: '90000000',
        imagen: 'auto15.jpg'
    }
];
