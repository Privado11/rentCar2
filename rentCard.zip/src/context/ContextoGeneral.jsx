import React, { createContext, useState } from 'react'
import { autos } from './api/listAutos';

export const contexto = createContext();

function ContextoGeneral({children}) {
  const [listaAutos,setListaAutos] = useState(autos);

  return (
    <contexto.Provider value={{
        listaAutos,setListaAutos
      }}>
        {children}
    </contexto.Provider>
  )
}

export default ContextoGeneral