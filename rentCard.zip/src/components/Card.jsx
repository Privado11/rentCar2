import React from 'react'
import '../styles/CardStyle.css'

function Card({auto}) {
    const {modelo,año,precio,imagen} = auto;
  return (
    <div className='card'>
        <div className='contenedorImagen'>
            <img src={imagen} alt="imagen de auto" />
        </div>
        <h2>{modelo} </h2>
        <p>{año} </p>
        <span>${precio} </span>
        <button>
            Rentar
        </button>
    </div>
  )
}

export default Card