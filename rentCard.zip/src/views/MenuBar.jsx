import React from 'react'
import '../styles/MenuBar.css'

function MenuBar() {
  return (
    <nav className='navBar'>
        <form action="">
            <label htmlFor="">Locacion:</label>
            <input type="text" name="" id="" placeholder='Ingrese la locacion'/>
            <label htmlFor="">Fecha Inicial:</label>
            <input type="date" name="" id="" />
            <label htmlFor="">Fecha Final:</label>
            <input type="date" name="" id="" />
            <button className='btnFiltro'>Filtrar</button>
        </form>
    </nav>
  )
}

export default MenuBar